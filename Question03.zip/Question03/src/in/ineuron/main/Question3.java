package in.ineuron.main;
import java.io.IOException;
import java.util.Scanner;

public class Question3 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		Scanner scan=new Scanner(System.in);
		System.out.println("enter number:: ");
		int num=scan.nextInt();
		try {
			if(num<0) {
				throw new Exception();	
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
