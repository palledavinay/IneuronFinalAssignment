package in.ineuron.service;

import java.util.List;

import in.ineuron.Exception.ProductNotFoundException;
import in.ineuron.model.Product;

public interface IProductService {
	public String saveEmployee(Product product);
	public List<Product> getAllProduct();
	public Product getProductById(Integer id)throws ProductNotFoundException;
	public String updateProduct(Product product) throws ProductNotFoundException;
	public String deleteProduct(Integer id)throws ProductNotFoundException;
	
}
