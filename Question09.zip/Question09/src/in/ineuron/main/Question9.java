package in.ineuron.main;

import java.util.Iterator;
import java.util.LinkedList;

public class Question9 {
	 public static void main(String[] args) throws InterruptedException{
		        final PC pc = new PC();
		 
		    
		        Thread t1 = new Thread(new Runnable() {
		            @Override
		            public void run()
		            {
		                try {
		                    pc.produce();
		                }
		                catch (InterruptedException e) {
		                    e.printStackTrace();
		                }
		            }
		        });
		 
		  
		        Thread t2 = new Thread(new Runnable() {
		            @Override
		            public void run()
		            {
		                try {
		                    pc.consume();
		                }
		                catch (InterruptedException e) {
		                    e.printStackTrace();
		                }
		            }
		        });
		
		        t1.start();
		        t2.start();
		        t1.join();
		        t2.join();
		    }
		 
		   
		    public static class PC {
		 
		       
		        LinkedList<Double> list = new LinkedList<Double>();
		        int capacity = 10;
		        public void produce() throws InterruptedException
		        {
		           for(int i=0;i<capacity;i++) {
		                synchronized (this)
		                {
		                    
		                    if(list.size()==capacity)
		                   notify();
		                    
		                    Double ran=Math.random();
		                    System.out.println(ran);
		                    list.add(ran);
		                  
		                    
		                } 
		                }
		            
		        }
		        public void consume() throws InterruptedException
		        {
		           
		                synchronized (this)
		                {
		                    
		             Double sum=0.0;
		             while(list.size()==0)
		            	 wait();
		             
		             Iterator itr=list.iterator();
		             while(itr.hasNext()) {
		            	 sum=sum+(Double)itr.next();
		             }
		             System.out.println("Sum of QQueue is:: "+sum);
		                }
		            }
		        
		    }
}