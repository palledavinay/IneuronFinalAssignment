package in.ineuron.service;

import in.ineuron.dto.Student;

public interface IStudentService {
	public Student searchStudent(Integer sid);
}
