package in.ineuron.main;

import java.util.Scanner;

public class Question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,2,3,4,5,6};
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the target value: ");
		int key=scan.nextInt();
		int low=0;
		int high=arr.length-1;
		while(low<=high) {
			int mid=(low+high)/2;
			if(arr[mid]==key) {
				System.out.println("key found at index "+mid);
				break;
			}
			else if(key>arr[mid]) {
				low=mid+1;
			}else if(key<arr[mid]) {
				high=mid-1;
			}
		}
		if(low>high) {
			System.out.println("key not found");
		}
	}

}
