package in.ineuron.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import in.ineuron.model.Register;

public interface IRegisterRepo extends CrudRepository<Register, Integer> {
	@Query("select count(*) from Register where email=:email and password=:password")
	public Integer validateUser(String eamil,String password);
}
