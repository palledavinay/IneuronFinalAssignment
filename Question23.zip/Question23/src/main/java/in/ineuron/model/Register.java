package in.ineuron.model;

import javax.persistence.Entity;

import lombok.Data;

@Data
@Entity
public class Register {
	
	private Integer no;
	private String name;
	private String email;
	private String password;
	private String gender;
	
}
