package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;

import in.ineuron.dao.IRegisterRepo;
import in.ineuron.model.Login;
import in.ineuron.model.Register;

public class RegisterServiceImpl implements IRegisterService {
	
	@Autowired
	private IRegisterRepo repo;
	
	@Override
	public String registerService(Register register) {
		
		Register reg=repo.save(register);
		return "registered succesfully";
	}

	@Override
	public String validateUser(Login login) {
		Integer user=repo.validateUser(login.getEmail(), login.getPassword());
		if(user>=1)
			return "matched";
		else
			return "unmatched";
	}
	
}
