package in.ineuron.service;

import in.ineuron.model.Login;
import in.ineuron.model.Register;

public interface IRegisterService {
	public String registerService(Register register);
	public String validateUser(Login login);
}
