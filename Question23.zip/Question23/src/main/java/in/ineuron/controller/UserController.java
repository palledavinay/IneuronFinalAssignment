package in.ineuron.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.ineuron.model.Login;
import in.ineuron.model.Register;
import in.ineuron.service.IRegisterService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private IRegisterService service;
	
	@GetMapping("/registerform")
	public String showForm(Map<String,Object> model) {
		Register user=new Register();
		model.put("user", user);
		return "register-form";
	}
	@PostMapping("/register")
	public String registerUser(@ModelAttribute("user") Register user,Map<String,Object> model) {
		if(user.getName()=="")
			return "redirect:./user/registerform";
		String msg = service.registerService(user);
		model.put("msg", msg);
		return "register-form";
	}
	@GetMapping("/loginform")
	public String showLoginForm(Map<String,Object> model) {
		Login login=new Login();
		model.put("login",login);
		return "login-form";
	}
	
	@GetMapping("/login")
	public String validateLogin(Map<String,Object> model,@ModelAttribute("login") Login login) {
		String msg = service.validateUser(login);
		if(msg=="matched") {
			msg="Credentials are "+msg+" and login successfull...";
			model.put("msg",msg);
			return "userpage";
		}
		else {
			msg="Invalid Credentials ,Try again after sometime...";
		    model.put("msg",msg);
			return "login-form";
		}
	}
}
