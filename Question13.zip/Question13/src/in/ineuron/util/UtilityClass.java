package in.ineuron.util;

import java.io.FileInputStream;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class UtilityClass {
	static {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver class loaded succesfuuly");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnect() throws IOException, SQLException {
		String location="src\\in\\ineuron\\properties\\dao.properties";
		FileInputStream fis=new FileInputStream(location);
		Properties properties=new Properties();
		properties.load(fis);
		Connection connection=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("user"),properties.getProperty("password"));
		return connection;
	}
	public static void closeResources(Connection c,Statement s,ResultSet rs) throws SQLException
	{
		if(c!=null)
			c.close();
		if(s!=null)
			s.close();
		if(rs!=null)
			rs.close();
		System.out.println("All Resources closed");
	}
	
	
}
