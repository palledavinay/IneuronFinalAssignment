package in.ineuron.test;

import java.util.Scanner;

import in.ineuron.dao.CricketerDaoLayer;
import in.ineuron.model.CricketerBO;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the id:: ");
		Integer id=scan.nextInt();
		System.out.print("Enter the Player name :: ");
		String name = scan.next();

		System.out.print("Enter the PLayer franchise :: ");
		String franchise= scan.next();

		System.out.print("Enter the Player team:: ");
		String team = scan.next();
		CricketerBO bo=new CricketerBO();
		bo.setId(id);
		bo.setName(name);
		bo.setFranchise(franchise);
		bo.setTeam(team);
		
		CricketerDaoLayer cric=new CricketerDaoLayer();
		String res=cric.registerCricketer(bo);
		if(res.equalsIgnoreCase("success"))
			cric.getDatas(bo.getId());
		else
			System.out.println("registration fail");
	}

}
