package in.ineuron.main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Question6 {

	public static void main(String[] args) {
		List<Double> percent=new ArrayList<Double>();
		percent.add(78.0);
    	percent.add(61.7);
    	percent.add(45.7);
    	percent.add(89.0);
    	percent.add(66.2);
    	percent.add(69.0);
    	percent.add(73.2);
    	percent.add(99.0);
    	percent.add(71.2);
    	percent.add(34.55);
    	percent.add(39.0);
    	percent.add(48.78);
    	percent.add(52.44);
    	
    	
    	//Filtering
    	List<Double> list=percent.stream().filter(i->(i>60.50)).collect(Collectors.toList());
    	
    	//After filtering
    	System.out.println("The filterd datas with percentage greater than 60.50%");
    	list.forEach(System.out::println);
    	
    	//Sorting the filtering data in ascending order
    	System.out.println("The filtered data in ascending order");
    	List<Double> sortAsc=list.stream().sorted().collect(Collectors.toList());
        sortAsc.forEach(System.out::println);
        
        //Sorting the filtering data in descending order
    	System.out.println("The filtered data in descending order");
    	List<Double> sortDesc=list.stream().sorted((perc1,perc2)->(perc2.compareTo(perc1))).collect(Collectors.toList());
        sortDesc.forEach(System.out::println);
    	 
	}

}
