package in.ineuron.service;

import in.ineuron.model.Book;

public interface IBookService {
	
	public String addBook(Book book);
	public Book getBookById(Integer id)throws Exception;
	

}
