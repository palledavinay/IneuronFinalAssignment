package in.ineuron.main;

interface IDemo{
	int a=110;
	void m1();
	//if we dont know implementation we know only specification.
	// by default every method is public abstract.
	//by default every variable is public static final.
	/*we cannot write static block,instance block,constructor because these are used for initialize 
	the variables but in interface while creating only we have to initialize the value because of final. */
}
abstract class Test{
	int a=230;
	public void m1() {
		
	}
	public abstract void m2();
	//it is preferred where partial implementation.
	//every method present inside abstract class no need to be public and abstract.
	//no need to be declare anything for variables.
	// static block,instance block,constructor are allowed because these all are used for initializing variable.
}
public class Question5 {

	public static void main(String[] args) {
		

	}

}
