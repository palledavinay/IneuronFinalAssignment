package in.ineuron.service;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.data.domain.Page;

import in.ineuron.model.Employee;

public interface IEmployeeService {
public List<Employee> getAllEmployeesBySorting(String order,String property);
	
	public Page<Employee> getAllEmployeesByPagination(Pageable pageable);
}
