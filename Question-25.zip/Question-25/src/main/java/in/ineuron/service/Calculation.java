package in.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class Calculation {
	public Double addNumbers(double num1,double num2) {
		Double sum=num1+num2;
		return sum;
	}
	public Double multiplyNumbers(double num1,double num2) {
		Double sum=num1*num2;
		return sum;
	}
}
