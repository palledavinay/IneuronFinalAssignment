package in.ineuron.main;
interface IShape{
	
	public abstract void areaShape();
	public abstract void perimeterShape();
	
}
class CirclesImpl implements IShape{
	int radius=8;
	double pi=3.14;
	public void areaShape() {
		double area=radius*pi;
		System.out.println(area);
	}
	public void perimeterShape() {
		double perimeter=2*(pi*radius);
		System.out.println(perimeter);
		
	}
	
}
class TriangleImpl implements IShape{
	int breadth=20;
	int height=10;
	int a=30;
	int b=10;
	int c=50;
	public void areaShape() {
		double area=0.5*(breadth*height);
		System.out.println(area);
	}
	public void perimeterShape() {
		int perimeter=a+b+c;
		System.out.println(perimeter);
	}
}
public class Question1 {

	public static void main(String[] args) {
		CirclesImpl c=new CirclesImpl();
		c.areaShape();
		c.perimeterShape();
		TriangleImpl t=new TriangleImpl();
		t.areaShape();
		t.perimeterShape();
	}

}
