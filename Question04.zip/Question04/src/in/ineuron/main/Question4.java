package in.ineuron.main;

import java.util.Scanner;

public class Question4 {

	public static void main(String[] args) {
		int balance=1000;
		String userId="vinaypalleda";
		String password="Palleda@4077";
		Scanner scan=new Scanner(System.in);
		System.out.println("Welcome to XYZ bank");
		System.out.println("enter your userid: ");
		String userId1=scan.next();
		System.out.println("enter your password: ");
		String password1=scan.next();
		if(userId.equalsIgnoreCase(userId1)) {
			if(password.equals(password1)) {
				System.out.println("login succesfully");
			}
			else {
				System.out.println("invalid password");
			}
		}
		else {
			System.out.println("invalid userId");
			System.out.println("please try again later");
			System.exit(0);
		}
		System.out.println("1.deposit");
		System.out.println("2. withdraw");
		System.out.println("3. Check Balance");
		System.out.println("please enter your option");
		int option=scan.nextInt();
		switch(option) {
		case 1:
			System.out.println("you have selected for deposit");
			System.out.println("please enter your deposit amount: ");
			int deposit=scan.nextInt();
			balance=deposit+balance;
			System.out.println("you have sucessfully deposited money");
			System.out.println("your final balance: "+ balance);
			break;
		case 2:
			System.out.println("you have enetered for withdraw");
			System.out.println("please enter withdraw amount: ");
			int withdraw=scan.nextInt();
			balance=withdraw+balance;
			System.out.println("you have withdraw money succesfully");
			System.out.println("your final balance is: "+balance);
			break;
		case 3:
			System.out.println("you have entered for balance enquiry");
			System.out.println("your account balance is: "+balance);
			break;
			default:
				System.out.println("you have entered invalid option ");
				System.exit(0);
		}
	}

}
