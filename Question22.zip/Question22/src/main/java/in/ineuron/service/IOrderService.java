package in.ineuron.service;

import java.util.List;

import in.ineuron.bo.Order;
import in.ineuron.bo.User;

public interface IOrderService {
	public List<Order> getAllOrders();
	public List<Order> getOrderByUser(User user);
	public String saveOrder(Order order);
	
}
