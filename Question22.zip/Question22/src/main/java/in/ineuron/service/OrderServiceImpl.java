package in.ineuron.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.ineuron.bo.Order;
import in.ineuron.bo.User;
import in.ineuron.dao.IOrderRepo;

public class OrderServiceImpl implements IOrderService{
	
	@Autowired
	private IOrderRepo repo;
	
	
	@Override
	public List<Order> getAllOrders() {
		return (List) repo.findAll();
		
	}

	@Override
	public List<Order> getOrderByUser(User user) {
		return (List) repo.findByUser(user);
		
	}

	@Override
	public String saveOrder(Order order) {
		return "Order added with id:: "+repo.save(order).getId();
	}
	

}
