package in.ineuron.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.ineuron.bo.User;
import in.ineuron.dao.IUsersRepo;

public class UserServiceImpl implements IUserService{
	@Autowired
	private IUsersRepo repo;

	@Override
	public String saveUser(User user) {
		
		return "user registration succesfull with id:: "+repo.save(user).getId();
	}

	@Override
	public List<User> getUsers() {
		return(List) repo.findAll();
	}
	

}
