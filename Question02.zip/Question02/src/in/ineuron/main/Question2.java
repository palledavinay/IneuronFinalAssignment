package in.ineuron.main;
class Parent{
	public Parent() {
		System.out.println("parent class constructor");
	}
}
class Child extends Parent{
	public Child() {
		super();
		System.out.println("child class constructor");
	}
}
public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c=new Child();
		
	}

}
//Constructor should same name as class name.
//it doest not have any return type.
//Constructor is called during object creation.
//In constructor at first line it should either super method or this method.
//we can't keep both together.
//super() will class parent class constructor.
//this() will call same class constructor.
//if we want to execute some statements at the moment of creation of object then we can go for constructor.
//constructor are two types:
//parameterized constructor means which will accept parameter.
//Default constructor means it will not accept any parameter.
