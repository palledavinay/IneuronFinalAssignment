package in.ineuron.dto;

import java.io.Serializable;

public class BlogPost implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String tittle;
	private String description;
	private String content;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTittle() {
		return tittle;
	}
	public void setTittle(String tittle) {
		this.tittle = tittle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "BlogPost [id=" + id + ", tittle=" + tittle + ", description=" + description + ", content=" + content
				+ "]";
	}
	
	
}
