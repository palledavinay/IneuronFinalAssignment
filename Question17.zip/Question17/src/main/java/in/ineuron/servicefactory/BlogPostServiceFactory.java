package in.ineuron.servicefactory;

import in.ineuron.service.BlogPostServiceImpl;
import in.ineuron.service.IBlogPostService;

public class BlogPostServiceFactory {
	private BlogPostServiceFactory() {
		
	}
	private static IBlogPostService blogpostservice=null;
	public static IBlogPostService getBlogPostService() {
		if(blogpostservice==null) {
			blogpostservice=new BlogPostServiceImpl();
			
		}
		
		return blogpostservice;
	}
	
}
