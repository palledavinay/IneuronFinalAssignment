package in.ineuron.service;

import java.util.List;

import in.ineuron.dao.IBlogPost;
import in.ineuron.daofactory.BlogPostDaoFactory;
import in.ineuron.dto.BlogPost;

public class BlogPostServiceImpl implements IBlogPostService {
	
	private IBlogPost blogpost;
	@Override
	public String createPost(BlogPost blogPost) {
		blogpost=BlogPostDaoFactory.getBlogPost();
		
		return blogpost.createPost(blogPost);
	}

	@Override
	public List<BlogPost> viewPost() {
		blogpost=BlogPostDaoFactory.getBlogPost();
		return blogpost.viewPost();
	}

}
