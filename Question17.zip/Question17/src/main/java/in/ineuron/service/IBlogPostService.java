package in.ineuron.service;

import java.util.List;

import in.ineuron.dto.BlogPost;

public interface IBlogPostService {
	public String createPost(BlogPost blogPost);
	public List<BlogPost> viewPost();
}
