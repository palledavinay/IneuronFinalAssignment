package in.ineuron.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.BlogPost;
import in.ineuron.service.IBlogPostService;
import in.ineuron.servicefactory.BlogPostServiceFactory;


@WebServlet("/test/*")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doProcess(request, response);
	}
	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IBlogPostService blogpostservice=BlogPostServiceFactory.getBlogPostService();
		
		System.out.println("Request URI :: "+request.getRequestURI());
		System.out.println("path info :: "+request.getPathInfo());
		
		if(request.getRequestURI().endsWith("create")) {
			String tittle=request.getParameter("tittle");
			String description=request.getParameter("description");
			String content=request.getParameter("content");
			
			BlogPost blogpost=new BlogPost();
			blogpost.setTittle(tittle);
			blogpost.setDescription(description);
			blogpost.setContent(content);
			
			String status=blogpostservice.createPost(blogpost);
			RequestDispatcher rd=null;
			
			if(status.equals("success")) {
				request.setAttribute("status", "success");
				rd=request.getRequestDispatcher("../createform.jsp");
				rd.forward(request, response);
			}
				else {
					request.setAttribute("status", "failure");
					rd=request.getRequestDispatcher("../createform.jsp");
					rd.forward(request, response);
				}
				
			
			
		}
		if (request.getRequestURI().endsWith("display")) {
			
			blogpostservice=BlogPostServiceFactory.getBlogPostService();
			List<BlogPost> posts=blogpostservice.viewPost();
			request.setAttribute("posts", posts);

			RequestDispatcher rd = null;
			rd = request.getRequestDispatcher("../displayform.jsp");
			rd.forward(request, response);
		}
	}

}
