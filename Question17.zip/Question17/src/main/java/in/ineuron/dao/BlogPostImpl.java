package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.dto.BlogPost;
import in.ineuron.util.JdbcUtil;

public class BlogPostImpl implements IBlogPost{
	
	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;
	@Override
	public String createPost(BlogPost blogPost) {
		String sqlInsertQuery="insert into blogpost(`tittle`,`description`,`content`)values(?,?,?)";
		try {
			connection=JdbcUtil.getJdbcConnection();
			
			if(connection!=null)
				pstmt=connection.prepareStatement(sqlInsertQuery);
			if(pstmt!=null) {
				pstmt.setString(2,blogPost.getTittle());
				pstmt.setString(3, blogPost.getDescription());
				pstmt.setString(4, blogPost.getContent());
				
				int rowAffected=pstmt.executeUpdate();
				if(rowAffected==1)
					return "success";
			}
		}catch(SQLException | IOException e) {
			e.printStackTrace();
		}
		return "failure";
	}

	@Override
	public List<BlogPost> viewPost() {
		List<BlogPost> posts=new ArrayList<BlogPost>();
		BlogPost blogPost=null;
		try {
			connection=JdbcUtil.getJdbcConnection();
			String sqlSelectQuery="select*from blogpost";
			if(connection!=null)
				pstmt=connection.prepareStatement(sqlSelectQuery);
			if(pstmt!=null) {
				resultSet=pstmt.executeQuery();
			}
			if(resultSet!=null) {
				while(resultSet.next()) {
					blogPost=new BlogPost();
					blogPost.setTittle(resultSet.getString(2));
					blogPost.setDescription(resultSet.getString(3));
					blogPost.setContent(resultSet.getString(4));
					posts.add(blogPost);
				}
			}
		}catch(SQLException | IOException e) {
			e.printStackTrace();
		}
		return posts;
	}

}
