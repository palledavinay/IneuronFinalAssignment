package in.ineuron.dao;

import java.util.List;

import in.ineuron.dto.BlogPost;

public interface IBlogPost {
	public String createPost(BlogPost blogPost);
	public List<BlogPost> viewPost();
}
